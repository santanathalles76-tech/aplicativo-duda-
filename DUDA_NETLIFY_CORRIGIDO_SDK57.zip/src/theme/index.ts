/**
 * Design System do DUDA — fonte única de cores, espaçamentos, raios e tipografia.
 */
import { Platform } from 'react-native';

export const colors = {
  sage: '#718C73',
  forest: '#405B48',
  cream: '#F7F5EC',
  softWhite: '#FFFDF7',
  lightGreen: '#E8EEE3',
  naturalGray: '#879184',
  blush: '#C88F82',
  gold: '#C49A56',
  // Derivadas (contraste de texto e divisórias)
  textPrimary: '#2F4437',
  textSecondary: '#5F6B5E',
  border: '#DCE3D5',
  white: '#FFFFFF',
} as const;

export const priorityColors = {
  alta: colors.blush,
  media: colors.gold,
  baixa: colors.sage,
} as const;

export const spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  xxl: 32,
} as const;

export const radius = {
  sm: 10,
  md: 16,
  lg: 24,
  pill: 999,
} as const;

export const shadow = {
  soft: {
    shadowColor: '#405B48',
    shadowOpacity: 0.08,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 4 },
    elevation: 2,
  },
} as const;

const serif = Platform.select({ ios: 'Georgia', default: 'serif' });

export const typography = {
  brand: { fontFamily: serif, fontSize: 22, fontWeight: '700', letterSpacing: 4 },
  title: { fontFamily: serif, fontSize: 26, fontWeight: '700' },
  heading: { fontSize: 18, fontWeight: '600' },
  body: { fontSize: 16, fontWeight: '400' },
  bodyStrong: { fontSize: 16, fontWeight: '600' },
  caption: { fontSize: 13, fontWeight: '400' },
  label: { fontSize: 12, fontWeight: '600', letterSpacing: 0.6 },
} as const;

/** Tamanho mínimo de toque recomendado pela Apple. */
export const MIN_TOUCH = 44;
