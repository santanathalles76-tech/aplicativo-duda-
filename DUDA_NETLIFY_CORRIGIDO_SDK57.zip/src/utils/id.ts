/** Gera identificadores únicos (tempo + aleatório) sem dependências nativas. */
export function generateId(): string {
  const rand = () => Math.random().toString(36).slice(2, 10);
  return `${Date.now().toString(36)}-${rand()}${rand()}`;
}
