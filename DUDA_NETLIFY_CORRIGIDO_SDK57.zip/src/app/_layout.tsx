import React, { useEffect } from 'react';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import * as SplashScreen from 'expo-splash-screen';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { TasksProvider, useTasks } from '../features/tasks/TasksContext';
import { colors, typography } from '../theme';
import { PwaSetup } from '../components/PwaSetup';

SplashScreen.preventAutoHideAsync().catch(() => {});

/** Mantém a Splash Screen até as tarefas serem lidas do armazenamento local. */
function Gate({ children }: { children: React.ReactNode }) {
  const { loaded } = useTasks();
  useEffect(() => {
    if (loaded) SplashScreen.hideAsync().catch(() => {});
  }, [loaded]);
  return loaded ? <>{children}</> : null;
}

export default function RootLayout() {
  return (
    <SafeAreaProvider>
      <TasksProvider>
        <PwaSetup />
        <Gate>
          <StatusBar style="dark" />
          <Stack
            screenOptions={{
              headerStyle: { backgroundColor: colors.cream },
              headerTintColor: colors.forest,
              headerTitleStyle: { fontFamily: typography.title.fontFamily, fontWeight: '700' },
              headerShadowVisible: false,
              contentStyle: { backgroundColor: colors.cream },
            }}
          >
            <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
            <Stack.Screen name="tasks/new" options={{ title: 'Nova tarefa', presentation: 'modal' }} />
            <Stack.Screen name="tasks/[id]" options={{ title: 'Editar tarefa', presentation: 'modal' }} />
          </Stack>
        </Gate>
      </TasksProvider>
    </SafeAreaProvider>
  );
}
