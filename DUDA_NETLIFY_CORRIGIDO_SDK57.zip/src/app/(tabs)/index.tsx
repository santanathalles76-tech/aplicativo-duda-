import React, { useMemo } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { Screen } from '../../components/Screen';
import { Avatar, Logo } from '../../components/Brand';
import { ProgressCard } from '../../components/ProgressCard';
import { TaskCard } from '../../components/TaskCard';
import { EmptyState } from '../../components/EmptyState';
import { AddButton } from '../../components/Buttons';
import { useTasks } from '../../features/tasks/TasksContext';
import {
  isOverdue,
  overdueFromPreviousDays,
  sortTasks,
  summarize,
  tasksForDate,
} from '../../features/tasks/taskLogic';
import { useConfirmDelete } from '../../hooks/useConfirmDelete';
import { useNow } from '../../hooks/useNow';
import { formatLongDate, greetingFor, toDateKey } from '../../utils/date';
import { motivationalMessage } from '../../utils/messages';
import { colors, radius, spacing, typography } from '../../theme';

export default function HomeScreen() {
  const router = useRouter();
  const now = useNow();
  const { tasks, error, toggleTaskStatus } = useTasks();
  const confirmDelete = useConfirmDelete();

  const todayKey = toDateKey(now);
  const todays = useMemo(() => tasksForDate(tasks, todayKey), [tasks, todayKey]);
  const pending = useMemo(() => sortTasks(todays.filter((t) => t.status === 'pendente')), [todays]);
  const done = useMemo(() => sortTasks(todays.filter((t) => t.status === 'concluida')), [todays]);
  const summary = useMemo(() => summarize(todays), [todays]);
  const lateCount = useMemo(() => overdueFromPreviousDays(tasks, now).length, [tasks, now]);

  const cardProps = {
    onToggle: (t: { id: string }) => toggleTaskStatus(t.id),
    onEdit: (t: { id: string }) => router.push({ pathname: '/tasks/[id]', params: { id: t.id } }),
    onDelete: confirmDelete,
  };

  return (
    <Screen>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.topRow}>
          <Logo />
          <Avatar />
        </View>

        <View style={styles.greeting}>
          <Text style={[typography.title, { color: colors.textPrimary }]}>
            {greetingFor(now)}, Maria Eduarda!
          </Text>
          <Text style={[typography.body, { color: colors.textSecondary }]}>{formatLongDate(now)}</Text>
          <Text style={[typography.body, { color: colors.forest, fontStyle: 'italic' }]}>
            {motivationalMessage(now)}
          </Text>
        </View>

        {error ? (
          <View accessibilityLiveRegion="polite" style={styles.errorBox}>
            <Text style={[typography.caption, { color: '#7A453A' }]}>{error}</Text>
          </View>
        ) : null}

        <ProgressCard summary={summary} />

        {lateCount > 0 ? (
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Ver tarefas atrasadas no Planejamento"
            onPress={() => router.push('/planejamento')}
            style={styles.lateBox}
          >
            <Text style={[typography.caption, { color: '#7A453A' }]}>
              {lateCount === 1
                ? 'Você tem 1 tarefa pendente de dias anteriores. Toque para ver no Planejamento.'
                : `Você tem ${lateCount} tarefas pendentes de dias anteriores. Toque para ver no Planejamento.`}
            </Text>
          </Pressable>
        ) : null}

        <Text style={[typography.heading, { color: colors.textPrimary }]}>Tarefas de hoje</Text>

        {todays.length === 0 ? (
          <EmptyState
            icon="sun"
            title="Nenhuma tarefa para hoje"
            message="Um dia livre! Se quiser, toque em “Nova tarefa” para planejar algo."
          />
        ) : (
          <View style={styles.list}>
            {pending.map((t) => (
              <TaskCard key={t.id} task={t} overdue={isOverdue(t, now)} {...cardProps} />
            ))}
            {done.length > 0 ? (
              <>
                <Text style={[typography.label, styles.sectionLabel]}>CONCLUÍDAS</Text>
                {done.map((t) => (
                  <TaskCard key={t.id} task={t} {...cardProps} />
                ))}
              </>
            ) : null}
          </View>
        )}
      </ScrollView>

      <AddButton onPress={() => router.push({ pathname: '/tasks/new', params: { date: todayKey } })} />
    </Screen>
  );
}

const styles = StyleSheet.create({
  content: { padding: spacing.lg, gap: spacing.lg, paddingBottom: 120 },
  topRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  greeting: { gap: spacing.xs },
  list: { gap: spacing.md },
  sectionLabel: { color: colors.naturalGray, marginTop: spacing.md },
  errorBox: { backgroundColor: '#F4E3DE', borderRadius: radius.sm, padding: spacing.md },
  lateBox: { backgroundColor: '#F7EBE7', borderRadius: radius.sm, padding: spacing.md, minHeight: 44, justifyContent: 'center' },
});
