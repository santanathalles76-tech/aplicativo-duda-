import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import type { Priority } from '../../types';
import { colors, priorityColors, radius, spacing, typography } from '../../theme';
import { PRIORITY_LABEL } from '../../features/tasks/taskLogic';

export function PriorityBadge({ priority }: { priority: Priority }) {
  const color = priorityColors[priority];
  return (
    <View
      accessible
      accessibilityLabel={`Prioridade ${PRIORITY_LABEL[priority].toLowerCase()}`}
      style={[styles.badge, { borderColor: color }]}
    >
      <View style={[styles.dot, { backgroundColor: color }]} />
      <Text style={[typography.label, { color: colors.textSecondary }]}>{PRIORITY_LABEL[priority]}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  badge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs + 2,
    borderWidth: 1,
    borderRadius: radius.pill,
    paddingHorizontal: spacing.sm + 2,
    paddingVertical: 3,
  },
  dot: { width: 7, height: 7, borderRadius: 4 },
});
