import React, { useEffect, useRef } from 'react';
import { Animated, Easing, StyleSheet, Text, View } from 'react-native';
import type { DaySummary } from '../../types';
import { colors, radius, shadow, spacing, typography } from '../../theme';

export function ProgressCard({ summary, title = 'Resumo do dia' }: { summary: DaySummary; title?: string }) {
  const progress = useRef(new Animated.Value(summary.percent)).current;

  useEffect(() => {
    Animated.timing(progress, {
      toValue: summary.percent,
      duration: 450,
      easing: Easing.out(Easing.cubic),
      useNativeDriver: false,
    }).start();
  }, [summary.percent, progress]);

  const width = progress.interpolate({ inputRange: [0, 100], outputRange: ['0%', '100%'] });

  return (
    <View style={[styles.card, shadow.soft]}>
      <View style={styles.headerRow}>
        <Text style={[typography.heading, { color: colors.textPrimary }]}>{title}</Text>
        <Text style={[typography.title, { color: colors.forest }]}>{summary.percent}%</Text>
      </View>

      <View
        accessible
        accessibilityRole="progressbar"
        accessibilityLabel={`Progresso: ${summary.percent} por cento`}
        accessibilityValue={{ min: 0, max: 100, now: summary.percent }}
        style={styles.track}
      >
        <Animated.View style={[styles.fill, { width }]} />
      </View>

      <View style={styles.stats}>
        <Stat label="Total" value={summary.total} />
        <Stat label="Concluídas" value={summary.done} />
        <Stat label="Pendentes" value={summary.pending} />
      </View>
    </View>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <View style={styles.stat}>
      <Text style={[typography.title, { color: colors.textPrimary }]}>{value}</Text>
      <Text style={[typography.caption, { color: colors.textSecondary }]}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.softWhite,
    borderRadius: radius.lg,
    padding: spacing.xl,
    gap: spacing.lg,
    borderWidth: 1,
    borderColor: colors.border,
  },
  headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  track: { height: 10, borderRadius: radius.pill, backgroundColor: colors.lightGreen, overflow: 'hidden' },
  fill: { height: '100%', borderRadius: radius.pill, backgroundColor: colors.sage },
  stats: { flexDirection: 'row', justifyContent: 'space-between' },
  stat: { alignItems: 'flex-start', gap: 2 },
});
