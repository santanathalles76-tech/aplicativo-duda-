import React from 'react';
import { Pressable, StyleSheet, Text, type ViewStyle } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { colors, MIN_TOUCH, radius, shadow, spacing, typography } from '../../theme';

interface ButtonProps {
  label: string;
  onPress: () => void;
  variant?: 'primary' | 'secondary' | 'danger';
  icon?: React.ComponentProps<typeof Feather>['name'];
  disabled?: boolean;
  style?: ViewStyle;
}

export function Button({ label, onPress, variant = 'primary', icon, disabled, style }: ButtonProps) {
  const palette = {
    primary: { bg: colors.forest, fg: colors.cream, border: colors.forest },
    secondary: { bg: colors.softWhite, fg: colors.forest, border: colors.border },
    danger: { bg: colors.softWhite, fg: '#9C5D50', border: colors.blush },
  }[variant];

  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={label}
      accessibilityState={{ disabled: !!disabled }}
      disabled={disabled}
      onPress={onPress}
      style={({ pressed }) => [
        styles.button,
        { backgroundColor: palette.bg, borderColor: palette.border },
        pressed && { opacity: 0.85 },
        disabled && { opacity: 0.5 },
        style,
      ]}
    >
      {icon ? <Feather name={icon} size={18} color={palette.fg} /> : null}
      <Text style={[typography.bodyStrong, { color: palette.fg }]}>{label}</Text>
    </Pressable>
  );
}

/** Botão flutuante de destaque para adicionar tarefa. */
export function AddButton({ onPress, label = 'Nova tarefa' }: { onPress: () => void; label?: string }) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={label}
      onPress={onPress}
      style={({ pressed }) => [styles.fab, shadow.soft, pressed && { opacity: 0.88, transform: [{ scale: 0.97 }] }]}
    >
      <Feather name="plus" size={20} color={colors.cream} />
      <Text style={[typography.bodyStrong, { color: colors.cream }]}>{label}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  button: {
    minHeight: MIN_TOUCH + 4,
    borderRadius: radius.md,
    borderWidth: 1,
    paddingHorizontal: spacing.xl,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.sm,
  },
  fab: {
    position: 'absolute',
    right: spacing.lg,
    bottom: spacing.lg,
    minHeight: 52,
    paddingHorizontal: spacing.xl,
    borderRadius: radius.pill,
    backgroundColor: colors.forest,
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
  },
});
